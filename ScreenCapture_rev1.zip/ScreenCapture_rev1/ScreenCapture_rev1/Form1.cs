﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging; //Extra Includes

namespace ScreenCapture_rev1
{
    public partial class Form1 : Form
    {
        int cropX;
        int cropY;
        int cropWidth;
        int cropHeight;
        int oCropX;
        int oCropY;
        Pen cropPen;

        bool cropMode = false; //Used to enable crop functionality

        public Form1()
        {
            InitializeComponent();
        }

        private void cap_Button_Click(object sender, EventArgs e)
        {
            this.Hide(); //Hide application while screen is captured
            System.Threading.Thread.Sleep(1000);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img = Clipboard.GetImage(); //Acquire image from clipboard
            img_Container.Image = img; //Set picturebox image to acquired image
            edit_Container.Image = img;
            this.Show(); //Resume application
        }

        private void imp_Button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)//Open file explorer
            {
                img_Container.Image = Image.FromFile(openFileDialog1.FileName);//Assign selected image to pictureboxes
                edit_Container.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void save_Button_Click(object sender, EventArgs e)
        {
            Image img = edit_Container.Image;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)//Open file explorer
            {
                string savePath = saveFileDialog1.FileName.ToString();
                savePath = savePath + ".jpg"; //Add jpg file extensio to save filepath
                img.Save(savePath);
            }
        }

        private void crop_Button_Click(object sender, EventArgs e)
        {
            if (cropMode == false)//Change color based on enabled functionality
            {
                crop_Button.BackColor = Color.Green;
                cropMode = true;
            }
            else
            {
                crop_Button.BackColor = Color.Red;
                cropMode = false;

                Cursor = Cursors.Default;

                Rectangle rect = new Rectangle(cropX, cropY, cropWidth, cropHeight);
                
                //First we define a rectangle with the help of already calculated points
                Bitmap OriginalImage = new Bitmap(edit_Container.Image, edit_Container.Width, edit_Container.Height);
                
                //Original image
                Bitmap _img = new Bitmap(cropWidth, cropHeight);
                
                // for cropinf image
                Graphics g = Graphics.FromImage(_img);
                
                // create graphics
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                
                //set image attributes
                g.DrawImage(OriginalImage, 0, 0, rect, GraphicsUnit.Pixel);
                edit_Container.Image = _img;
                edit_Container.Width = _img.Width;
                edit_Container.Height = _img.Height;
            }
        }

        private void crop_Button_MouseDown(object sender, MouseEventArgs e)
        {
            if (cropMode == false) //Start crop selection
            {
                Cursor = Cursors.Cross;
                cropX = e.X;
                cropY = e.Y;
                cropPen = new Pen(Color.Black, 1);
                cropPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            }

            edit_Container.Refresh();
        }

        private void edit_Container_MouseMove(object sender, MouseEventArgs e)
        {
            if (edit_Container.Image == null)
            {
                return;
            }
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                edit_Container.Refresh();
                cropWidth = e.X - cropX;
                cropHeight = e.Y - cropY;
                edit_Container.CreateGraphics().DrawRectangle(cropPen, cropX, cropY, cropWidth, cropHeight);
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            float value = trackBar1.Value * 0.01f;

            float[][] colorMatrixElements = {
            new float[] {1,0,0,0,0},
            new float[] {0,1,0,0,0},
            new float[] {0,0,1,0,0},
            new float[] {0,0,0,1,0},
            new float[] {value,value,value,0,1}
            };

            ColorMatrix colorMatrix = new ColorMatrix(colorMatrixElements);

            ImageAttributes imageAttributes = new ImageAttributes();
            imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            Image _img = edit_Container.Image;
            Graphics _g = default(Graphics);
            Bitmap bm_dest = new Bitmap(Convert.ToInt32(_img.Width), Convert.ToInt32(_img.Height));
            _g = Graphics.FromImage(bm_dest);
            _g.DrawImage(_img, new Rectangle(0, 0, bm_dest.Width + 1, bm_dest.Height + 1), 0, 0, bm_dest.Width + 1, bm_dest.Height + 1, GraphicsUnit.Pixel, imageAttributes);
            edit_Container.Image = bm_dest;
        }
    }
}
