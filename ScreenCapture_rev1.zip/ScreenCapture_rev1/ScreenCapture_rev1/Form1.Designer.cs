﻿namespace ScreenCapture_rev1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cap_Button = new System.Windows.Forms.Button();
            this.imp_Button = new System.Windows.Forms.Button();
            this.img_Container = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.edit_Container = new System.Windows.Forms.PictureBox();
            this.save_Button = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.crop_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.img_Container)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edit_Container)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // cap_Button
            // 
            this.cap_Button.Location = new System.Drawing.Point(6, 22);
            this.cap_Button.Name = "cap_Button";
            this.cap_Button.Size = new System.Drawing.Size(196, 84);
            this.cap_Button.TabIndex = 0;
            this.cap_Button.Text = "Capture";
            this.cap_Button.UseVisualStyleBackColor = true;
            this.cap_Button.Click += new System.EventHandler(this.cap_Button_Click);
            // 
            // imp_Button
            // 
            this.imp_Button.Location = new System.Drawing.Point(208, 22);
            this.imp_Button.Name = "imp_Button";
            this.imp_Button.Size = new System.Drawing.Size(196, 84);
            this.imp_Button.TabIndex = 1;
            this.imp_Button.Text = "Import";
            this.imp_Button.UseVisualStyleBackColor = true;
            this.imp_Button.Click += new System.EventHandler(this.imp_Button_Click);
            // 
            // img_Container
            // 
            this.img_Container.BackColor = System.Drawing.Color.White;
            this.img_Container.Location = new System.Drawing.Point(3, 112);
            this.img_Container.Name = "img_Container";
            this.img_Container.Size = new System.Drawing.Size(1867, 1055);
            this.img_Container.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_Container.TabIndex = 2;
            this.img_Container.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1896, 1231);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cap_Button);
            this.tabPage1.Controls.Add(this.img_Container);
            this.tabPage1.Controls.Add(this.imp_Button);
            this.tabPage1.Location = new System.Drawing.Point(10, 48);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1876, 1173);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Capture";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.trackBar1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.crop_Button);
            this.tabPage2.Controls.Add(this.save_Button);
            this.tabPage2.Controls.Add(this.edit_Container);
            this.tabPage2.Location = new System.Drawing.Point(10, 48);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1876, 1173);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Edit";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // edit_Container
            // 
            this.edit_Container.BackColor = System.Drawing.Color.White;
            this.edit_Container.Location = new System.Drawing.Point(2, 142);
            this.edit_Container.Name = "edit_Container";
            this.edit_Container.Size = new System.Drawing.Size(1867, 1025);
            this.edit_Container.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.edit_Container.TabIndex = 3;
            this.edit_Container.TabStop = false;
            this.edit_Container.MouseMove += new System.Windows.Forms.MouseEventHandler(this.edit_Container_MouseMove);
            // 
            // save_Button
            // 
            this.save_Button.Location = new System.Drawing.Point(745, 22);
            this.save_Button.Name = "save_Button";
            this.save_Button.Size = new System.Drawing.Size(196, 114);
            this.save_Button.TabIndex = 4;
            this.save_Button.Text = "Save";
            this.save_Button.UseVisualStyleBackColor = true;
            this.save_Button.Click += new System.EventHandler(this.save_Button_Click);
            // 
            // crop_Button
            // 
            this.crop_Button.Location = new System.Drawing.Point(5, 22);
            this.crop_Button.Name = "crop_Button";
            this.crop_Button.Size = new System.Drawing.Size(196, 114);
            this.crop_Button.TabIndex = 5;
            this.crop_Button.Text = "Crop";
            this.crop_Button.UseVisualStyleBackColor = true;
            this.crop_Button.Click += new System.EventHandler(this.crop_Button_Click);
            this.crop_Button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.crop_Button_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(217, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 32);
            this.label1.TabIndex = 6;
            this.label1.Text = "Brightness:";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(390, 22);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(349, 114);
            this.trackBar1.TabIndex = 7;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1911, 1236);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.img_Container)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edit_Container)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cap_Button;
        private System.Windows.Forms.Button imp_Button;
        private System.Windows.Forms.PictureBox img_Container;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox edit_Container;
        private System.Windows.Forms.Button save_Button;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button crop_Button;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label1;
    }
}

