﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging; //Extra Includes
using System.Windows.Media.Imaging;
using System.Windows.Interop;
using System.Windows;
using System.IO;

namespace ScreenCapture_rev1
{
    public partial class form1 : Form
    {
        int cropX;
        int cropY;
        int cropWidth;
        int cropHeight;
        int oCropX;
        int oCropY;
        Pen cropPen;
        int defaultWidth = 0;
        int defaultHeight = 0;
        bool newCrop = true;
        Bitmap origImg;
        Image[] frames = new Image[75];
        Image[] img = new Image[75];
        int tick = 0;

        bool cropMode = false; //Used to enable crop functionality

        public form1()
        {
            InitializeComponent();
        }

        private void cap_Button_Click(object sender, EventArgs e)
        {
            this.Hide(); //Hide application while screen is captured
            System.Threading.Thread.Sleep(1000);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            img_Container.Image = img; //Set picturebox image to acquired image
            edit_Container.Image = img;
            this.Show(); //Resume application
        }

        private void imp_Button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)//Open file explorer
            {
                img_Container.Image = Image.FromFile(openFileDialog1.FileName);//Assign selected image to pictureboxes
                edit_Container.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void save_Button_Click(object sender, EventArgs e)
        {
            Image img = edit_Container.Image;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)//Open file explorer
            {
                string savePath = saveFileDialog1.FileName.ToString();
                img.Save(savePath);
            }
        }

        private void crop_Button_Click(object sender, EventArgs e)
        {
            if (cropMode == false)//Change color based on enabled functionality
            {
                crop_Button.BackColor = Color.Green;
                cropMode = true;
            }
            else
            {
                
                if(newCrop == true)
                {
                    newCrop = false;
                    defaultWidth = edit_Container.Width;
                    defaultHeight = edit_Container.Height;
                }
                crop_Button.BackColor = Color.Red;
                cropMode = false;

                Cursor = Cursors.Default;

                if (cropWidth <= 1 || cropHeight <= 1)
                {
                    return;
                }

                Rectangle rect = new Rectangle(cropX, cropY, cropWidth, cropHeight);
                
                //First we define a rectangle with the help of already calculated points
                Bitmap OriginalImage = new Bitmap(edit_Container.Image, edit_Container.Width, edit_Container.Height);
                
                //Original image
                Bitmap _img = new Bitmap(cropWidth, cropHeight);
                
                // for cropinf image
                Graphics g = Graphics.FromImage(_img);
                
                // create graphics
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                
                //set image attributes
                g.DrawImage(OriginalImage, 0, 0, rect, GraphicsUnit.Pixel);
                edit_Container.Image = _img;
                edit_Container.Width = _img.Width;
                edit_Container.Height = _img.Height;

                cropX = 0;
                cropY = 0;
                cropWidth = 0;
                cropHeight = 0;
                oCropX = 0;
                oCropY = 0;

                System.Windows.Forms.Clipboard.SetImage(_img);
            }
        }

        private void crop_Button_MouseDown(object sender, MouseEventArgs e)
        {
            if (cropMode == false) //Start crop selection
            {
                Cursor = Cursors.Cross;
                cropX = e.X;
                cropY = e.Y;
                cropPen = new Pen(Color.Black, 1);
                cropPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
            }

            edit_Container.Refresh();
        }

        private void edit_Container_MouseMove(object sender, MouseEventArgs e)
        {
            if (edit_Container.Image == null)
            {
                return;
            }
            if (e.Button == System.Windows.Forms.MouseButtons.Left && cropMode == true)
            {
                edit_Container.Refresh();
                cropWidth = e.X - cropX;
                cropHeight = e.Y - cropY;
                edit_Container.CreateGraphics().DrawRectangle(cropPen, cropX, cropY, cropWidth, cropHeight);

                
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            float value = trackBar1.Value * 0.01f;

            float[][] colorMatrixElements = {
            new float[] {1,0,0,0,0},
            new float[] {0,1,0,0,0},
            new float[] {0,0,1,0,0},
            new float[] {0,0,0,1,0},
            new float[] {value,value,value,0,1}
            };

            ColorMatrix colorMatrix = new ColorMatrix(colorMatrixElements);

            ImageAttributes imageAttributes = new ImageAttributes();
            imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            Image _img = edit_Container.Image;
            origImg = (Bitmap)System.Windows.Forms.Clipboard.GetImage();
            Graphics _g = default(Graphics);
            try
            { 
                Bitmap bm_dest = new Bitmap(Convert.ToInt32(_img.Width), Convert.ToInt32(_img.Height));
            _g = Graphics.FromImage(_img);
            _g.DrawImage(origImg, new Rectangle(0, 0, bm_dest.Width + 1, bm_dest.Height + 1), 0, 0, bm_dest.Width + 1, bm_dest.Height + 1, GraphicsUnit.Pixel, imageAttributes);
            }
            catch(Exception x)
            {
                tabControl1.TabPages[1].Refresh();
            }
            edit_Container.Image = _img;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {

                edit_Container.Width = defaultWidth;
                edit_Container.Height = defaultHeight;
                Image defaultImage = img_Container.Image;
                edit_Container.Image = defaultImage;
            }
            else
            {

            }
        }

        private void rec_Button_Click(object sender, EventArgs e)
        {
        /*    this.Hide(); //Hide application while screen is captured
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img = Clipboard.GetImage(); //Acquire image from clipboard
            frames[0] = img;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img1 = Clipboard.GetImage(); //Acquire image from clipboard
            frames[1] = img1;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img2 = Clipboard.GetImage(); //Acquire image from clipboard
            frames[2] = img2;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img3 = Clipboard.GetImage(); //Acquire image from clipboard
            frames[3] = img3;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img4 = Clipboard.GetImage(); //Acquire image from clipboard
            frames[4] = img4;
            System.Threading.Thread.Sleep(500);

            timer1.Enabled = true;
            this.Show(); //Resume application  */     
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (tick == 0)
            {
                for (int i = 0; i < 15; i++)
                {
                    animation_Container.Image = frames[i]; 
                }
                tick =  1;
            }
            else if(tick == 1)
            {
                for (int i = 15; i < 30; i++)
                {
                    animation_Container.Image = frames[i];
                }
                tick = 2;
            }
            else if (tick == 2)
            {
                for (int i = 30; i < 45; i++)
                {
                    animation_Container.Image = frames[i];
                }
                tick = 3;
            }
            else if (tick == 3)
            {
                for (int i = 45; i < 60; i++)
                {
                    animation_Container.Image = frames[i];
                }
                tick = 4;
            }
            else if (tick == 4)
            {
                for (int i = 60; i < 75; i++)
                {
                    animation_Container.Image = frames[i];
                }
                tick = 0;
            }
            /*else if (tick == 5)
            {
                animation_Container.Image = frames[5];
                tick = 0;
            }
            */
        }

        private void rec_Button_Click_1(object sender, EventArgs e)
        {
            this.Hide(); //Hide application while screen is captured
            System.Threading.Thread.Sleep(500);
            for (int i = 0; i < 75; i++)
            {
                SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
                img[i] = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
                frames[i] = img[i];
                System.Threading.Thread.Sleep(1);
            }
            /*SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[0] = img;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img1 = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[1] = img1;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img2 = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[2] = img2;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img3 = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[3] = img3;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img4 = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[4] = img4;
            System.Threading.Thread.Sleep(500);
            SendKeys.Send("{PRTSC}"); //Trigger Printscreen key functionality
            Image img5 = System.Windows.Forms.Clipboard.GetImage(); //Acquire image from clipboard
            frames[5] = img5;
            System.Threading.Thread.Sleep(500);
            */
            timer1.Enabled = true;
            tabControl1.SelectedIndex = 2;
            this.Show(); //Resume application            
        }

        private void saveAnimation_Button_Click(object sender, EventArgs e)
        {
            try
            {
                System.Windows.Media.Imaging.GifBitmapEncoder gEnc = new GifBitmapEncoder();

                foreach (System.Drawing.Bitmap bmpImage in frames)
                {
                    var bmp = bmpImage.GetHbitmap();
                    var src = Imaging.CreateBitmapSourceFromHBitmap(
                        bmp,
                        IntPtr.Zero,
                        Int32Rect.Empty,
                        BitmapSizeOptions.FromEmptyOptions());
                    gEnc.Frames.Add(BitmapFrame.Create(src));
                    //DeleteObject(bmp); // recommended, handle memory leak
                }
                saveFileDialog1.ShowDialog();

                // If the file name is not an empty string open it for saving.
                if (saveFileDialog1.FileName != "")
                {
                    
                    // Saves the Image via a FileStream created by the OpenFile method.
                    System.IO.FileStream fs =
                       (System.IO.FileStream)saveFileDialog1.OpenFile();
                    
                    // Saves the Image in the appropriate ImageFormat based upon the
                    // File type selected in the dialog box.
                    // NOTE that the FilterIndex property is one-based.
                    gEnc.Save(fs);

                    fs.Close();
                    
                }
            }
            catch(Exception x)
            {

            }
        }

        private void ScreenCap_Load(object sender, EventArgs e)
        {

        }
    }
}
