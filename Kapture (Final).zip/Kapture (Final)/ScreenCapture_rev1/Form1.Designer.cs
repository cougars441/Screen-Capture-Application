﻿namespace ScreenCapture_rev1
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form1));
            this.cap_Button = new System.Windows.Forms.Button();
            this.imp_Button = new System.Windows.Forms.Button();
            this.img_Container = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rec_Button = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.crop_Button = new System.Windows.Forms.Button();
            this.save_Button = new System.Windows.Forms.Button();
            this.edit_Container = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.saveAnimation_Button = new System.Windows.Forms.Button();
            this.animation_Container = new System.Windows.Forms.PictureBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.img_Container)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_Container)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animation_Container)).BeginInit();
            this.SuspendLayout();
            // 
            // cap_Button
            // 
            this.cap_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.cap_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cap_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cap_Button.ForeColor = System.Drawing.Color.Black;
            this.cap_Button.Location = new System.Drawing.Point(15, 9);
            this.cap_Button.Margin = new System.Windows.Forms.Padding(1);
            this.cap_Button.Name = "cap_Button";
            this.cap_Button.Size = new System.Drawing.Size(80, 35);
            this.cap_Button.TabIndex = 0;
            this.cap_Button.Text = "Capture";
            this.cap_Button.UseVisualStyleBackColor = false;
            this.cap_Button.Click += new System.EventHandler(this.cap_Button_Click);
            // 
            // imp_Button
            // 
            this.imp_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.imp_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.imp_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imp_Button.ForeColor = System.Drawing.Color.Black;
            this.imp_Button.Location = new System.Drawing.Point(215, 9);
            this.imp_Button.Margin = new System.Windows.Forms.Padding(1);
            this.imp_Button.Name = "imp_Button";
            this.imp_Button.Size = new System.Drawing.Size(80, 35);
            this.imp_Button.TabIndex = 1;
            this.imp_Button.Text = "Import";
            this.imp_Button.UseVisualStyleBackColor = false;
            this.imp_Button.Click += new System.EventHandler(this.imp_Button_Click);
            // 
            // img_Container
            // 
            this.img_Container.BackColor = System.Drawing.Color.Transparent;
            this.img_Container.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("img_Container.BackgroundImage")));
            this.img_Container.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.img_Container.Location = new System.Drawing.Point(1, 49);
            this.img_Container.Margin = new System.Windows.Forms.Padding(1);
            this.img_Container.Name = "img_Container";
            this.img_Container.Size = new System.Drawing.Size(700, 442);
            this.img_Container.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_Container.TabIndex = 2;
            this.img_Container.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Broadway", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(11, 2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(711, 516);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage1.Controls.Add(this.rec_Button);
            this.tabPage1.Controls.Add(this.cap_Button);
            this.tabPage1.Controls.Add(this.img_Container);
            this.tabPage1.Controls.Add(this.imp_Button);
            this.tabPage1.Font = new System.Drawing.Font("Monotype Corsiva", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage1.Size = new System.Drawing.Size(703, 488);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Capture";
            // 
            // rec_Button
            // 
            this.rec_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.rec_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.rec_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rec_Button.ForeColor = System.Drawing.Color.Black;
            this.rec_Button.Location = new System.Drawing.Point(115, 9);
            this.rec_Button.Margin = new System.Windows.Forms.Padding(1);
            this.rec_Button.Name = "rec_Button";
            this.rec_Button.Size = new System.Drawing.Size(80, 35);
            this.rec_Button.TabIndex = 3;
            this.rec_Button.Text = "Record";
            this.rec_Button.UseVisualStyleBackColor = false;
            this.rec_Button.Click += new System.EventHandler(this.rec_Button_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage2.Controls.Add(this.trackBar1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.crop_Button);
            this.tabPage2.Controls.Add(this.save_Button);
            this.tabPage2.Controls.Add(this.edit_Container);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage2.Size = new System.Drawing.Size(703, 488);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Edit";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(220, 9);
            this.trackBar1.Margin = new System.Windows.Forms.Padding(1);
            this.trackBar1.Minimum = -10;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(131, 45);
            this.trackBar1.TabIndex = 7;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(115, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Brightness:";
            // 
            // crop_Button
            // 
            this.crop_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.crop_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.crop_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crop_Button.ForeColor = System.Drawing.Color.Black;
            this.crop_Button.Location = new System.Drawing.Point(15, 9);
            this.crop_Button.Margin = new System.Windows.Forms.Padding(1);
            this.crop_Button.Name = "crop_Button";
            this.crop_Button.Size = new System.Drawing.Size(80, 35);
            this.crop_Button.TabIndex = 5;
            this.crop_Button.Text = "Crop";
            this.crop_Button.UseVisualStyleBackColor = false;
            this.crop_Button.Click += new System.EventHandler(this.crop_Button_Click);
            this.crop_Button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.crop_Button_MouseDown);
            // 
            // save_Button
            // 
            this.save_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.save_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.save_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_Button.ForeColor = System.Drawing.Color.Black;
            this.save_Button.Location = new System.Drawing.Point(375, 9);
            this.save_Button.Margin = new System.Windows.Forms.Padding(1);
            this.save_Button.Name = "save_Button";
            this.save_Button.Size = new System.Drawing.Size(80, 35);
            this.save_Button.TabIndex = 4;
            this.save_Button.Text = "Save";
            this.save_Button.UseVisualStyleBackColor = false;
            this.save_Button.Click += new System.EventHandler(this.save_Button_Click);
            // 
            // edit_Container
            // 
            this.edit_Container.BackColor = System.Drawing.Color.Transparent;
            this.edit_Container.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("edit_Container.BackgroundImage")));
            this.edit_Container.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.edit_Container.Location = new System.Drawing.Point(1, 55);
            this.edit_Container.Margin = new System.Windows.Forms.Padding(1);
            this.edit_Container.Name = "edit_Container";
            this.edit_Container.Size = new System.Drawing.Size(700, 430);
            this.edit_Container.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.edit_Container.TabIndex = 3;
            this.edit_Container.TabStop = false;
            this.edit_Container.MouseMove += new System.Windows.Forms.MouseEventHandler(this.edit_Container_MouseMove);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage3.Controls.Add(this.saveAnimation_Button);
            this.tabPage3.Controls.Add(this.animation_Container);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage3.Size = new System.Drawing.Size(703, 488);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Animation";
            // 
            // saveAnimation_Button
            // 
            this.saveAnimation_Button.BackColor = System.Drawing.Color.PaleTurquoise;
            this.saveAnimation_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.saveAnimation_Button.Font = new System.Drawing.Font("Lucida Handwriting", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveAnimation_Button.Location = new System.Drawing.Point(15, 9);
            this.saveAnimation_Button.Margin = new System.Windows.Forms.Padding(1);
            this.saveAnimation_Button.Name = "saveAnimation_Button";
            this.saveAnimation_Button.Size = new System.Drawing.Size(80, 35);
            this.saveAnimation_Button.TabIndex = 5;
            this.saveAnimation_Button.Text = "Save";
            this.saveAnimation_Button.UseVisualStyleBackColor = false;
            this.saveAnimation_Button.Click += new System.EventHandler(this.saveAnimation_Button_Click);
            // 
            // animation_Container
            // 
            this.animation_Container.BackColor = System.Drawing.Color.Transparent;
            this.animation_Container.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("animation_Container.BackgroundImage")));
            this.animation_Container.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.animation_Container.Location = new System.Drawing.Point(1, 60);
            this.animation_Container.Margin = new System.Windows.Forms.Padding(1);
            this.animation_Container.Name = "animation_Container";
            this.animation_Container.Size = new System.Drawing.Size(700, 421);
            this.animation_Container.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.animation_Container.TabIndex = 4;
            this.animation_Container.TabStop = false;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "gif";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(734, 531);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "form1";
            this.Text = "Kapture";
            this.Load += new System.EventHandler(this.ScreenCap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.img_Container)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_Container)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.animation_Container)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cap_Button;
        private System.Windows.Forms.Button imp_Button;
        private System.Windows.Forms.PictureBox img_Container;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox edit_Container;
        private System.Windows.Forms.Button save_Button;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button crop_Button;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button rec_Button;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox animation_Container;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button saveAnimation_Button;
    }
}

